module.exports = {
  purge: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    colors: {
      transparent: 'transparent',
      current: 'currentColor',
      primary: "#66C1FF",
      gray: "#b1b1b1",
      white: "#ffffff",
      black: "#000000",
      secondary: "#811EA4",
      accent: "#84732B",
      lighter: "#574F2A",
      darker: "#290000"
    },
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
