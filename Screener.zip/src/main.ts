import { createApp } from 'vue'
import App from './App.vue'
import './style.css'
import {createRouter, createWebHistory} from 'vue-router'
import firebase from "./firebase";

import Intro from './pages/Intro.vue';
import Filter from './pages/Filter.vue';
import Screen from './pages/Screen.vue';

const app = createApp(App);
app.use(createRouter({
    history: createWebHistory(),
    routes: [
        {path: '/filter', component: Filter},
        {path: '/screen', component: Screen},
        {path: '/:pathMatch(.*)*', component: Intro}
    ]
}))
app.use(firebase)

app.mount('#app')
