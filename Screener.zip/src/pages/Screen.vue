<template>
  <div class="flex-row w-full h-full">

    <div class="flex justify-between card mb-16">
      <div class="title">Data Screener</div>
      <router-link to="/filter" class="flex items-center button">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </router-link>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 px-4">
      <div class="card rounded m-4" v-for="filter in filters">
        <div class="flex justify-between">
          <div class="title">{{filter.title}}</div>
          <button class="button" @click="removeFilter(filter.id)">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="current" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div class="flex mt-4 flex-wrap">
          <div v-for="s in filter.symbols.split(' ')">
            <template v-if="s!==''">
              <div class="rounded-full text-xl text-primary bg-darker px-4 m-1">{{s}}</div>
            </template>
          </div>
        </div>
        <button class="button opacity-50 w-full mt-4" @click="filter.detail=!filter.detail">Rules</button>

        <table v-if="filter.detail" class="table border-separate border-primary bg-lighter rounded">
          <thead>
          <tr>
            <th v-for="title in ['Indicator', 'TimeFrame', 'Condition', 'Value']">{{title}}</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="r in filter.rules" class="text-xl bg-gray">
            <td v-for="v in ['indicator', 'tf', 'condition']">{{r[v]}}</td>
            <td>{{`${r['compare']}: ${r['value']}`}}</td>
          </tr>
          </tbody>
        </table>

      </div>
    </div>


    <div class="card rounded mx-8 mt-16">
      <div class="title">Symbols</div>
      <div class="flex mt-4 flex-wrap">
        <div class="rounded-full text-xl flex flex-row text-primary bg-darker px-4 m-1" v-for="s in data">
          {{s.symbol}}
          <button class="ml-2 hover:text-white" @click="removeSymbol(s.symbol)">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="current" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 px-4">
      <div class="card rounded m-4">
        <div class="title">Indicators</div>
        <div class="flex mt-4 flex-wrap">
          <div class="rounded-full text-xl flex flex-row text-primary bg-darker px-4 m-1" v-for="i in indicators">
            {{i}}
            <button class="ml-2 hover:text-white" @click="removeIndicator(i)">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="current" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      <div class="card rounded m-4">
        <div class="title">Timeframes</div>
        <div class="flex mt-4 flex-wrap">
          <div class="rounded-full text-xl flex flex-row text-primary bg-darker px-4 m-1" v-for="t in timeframes">
            {{t}}
            <button class="ml-2 hover:text-white" @click="removeTimeframe(t)">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="current" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="w-full px-8 mb-16 pb-64">
      <table class="w-full table border-separate border-primary text-white text-2xl rounded">
        <thead>
        <tr class="bg-secondary">
          <th v-for="title in ['Symbol', 'Recent Update']">{{title}}</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="d in data" class="text-xl bg-gray">
          <td v-for="v in ['symbol', 'last']">{{d[v]}}</td>
        </tr>
        </tbody>
      </table>
    </div>

  </div>
</template>

<script>
export default {
  name: "Screen",
  props: ['filters', 'data', 'symbols', 'timeframes', 'indicators'],
  methods: {
    removeFilter(filter){this.FILTERS.doc(filter).delete()},
    removeSymbol(symbol){this.DATA.doc(symbol).delete()},
    removeIndicator(indicator){
      let batch = this.FIRESTORE.batch();
      this.data.forEach( s => {
        if (typeof s==='object'){
          if (indicator in s) {
            s[indicator] = this.FIELD_VALUE.delete()
            delete s['indicators'];
            batch.update(this.DATA.doc(s.symbol), s);
          }
        }
      });
      batch.commit().catch(e => console.log(e))
    },
    removeTimeframe(timeframe){
      let batch = this.FIRESTORE.batch()
      this.data.forEach( s => {
        Object.keys(s).forEach(k => {
          let d = s[k];
          if (typeof d==='object'){
            if (timeframe in d) {
              delete s[k][timeframe];
              batch.update(this.DATA.doc(s.symbol), s);
            }
          }
        })
      });
      batch.commit().catch(e => console.log(e))
    }
  }
}
</script>

<style scoped>

</style>