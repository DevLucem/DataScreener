<template>
  <div class="card flex flex-col rounded w-1/2">
    <div class="text-primary text-2xl font-bold mt-2 mx-auto">Create Filter</div>
    <div class="flex space-x-4">
      <input type="text" aria-label="none" placeholder="Title" class="flex-1 textput" v-model="filter.title">
      <input type="text" aria-label="none" placeholder="Telegram" class="flex-none textput" v-model="filter.alert">
    </div>

    <table class="table border-separate border-primary bg-lighter rounded">
      <thead>
        <tr>
          <th v-for="title in ['Indicator', 'TimeFrame', 'Condition', 'Value']">{{title}}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="r in filter.rules" class="text-xl bg-gray">
          <td v-for="v in ['indicator', 'tf', 'condition']">{{r[v]}}</td>
          <td>{{`${r['compare']}: ${r['value']}`}}</td>
        </tr>
      </tbody>
    </table>

    <div class="bg-lighter p-4 text-primary">
      <div class="mt-16 flex justify-between">
        <div>
          <label for="indicator" class="text-white mr-4">Indicator</label>
          <select class="px-4 bg-transparent border border-green-700 rounded" aria-label="none" name="Select" id="indicator" v-model="rule.indicator">
            <option v-for="option in indicators" :key="option" :value="option">{{option}}</option>
          </select>
        </div>
        <div>
          <label for="timeframe" class="text-white mr-4">Timeframe</label>
          <select class="px-4 bg-transparent border border-green-700 rounded" aria-label="none" name="Select" id="timeframe" v-model="rule.tf">
            <option v-for="option in timeframes" :key="option" :value="option">{{option}}</option>
          </select>
        </div>
        <div>
          <label for="condition" class="text-white mr-4">Condition</label>
          <select class="px-4 bg-transparent border border-green-700 rounded" aria-label="none" name="Select" id="condition" v-model="rule.condition">
            <option v-for="option in ['>', '<', '==', '>=', '<=']" :key="option" :value="option">{{option}}</option>
          </select>
        </div>
      </div>

      <div class="flex justify-between mt-8">
        <div class="my-4">
          <label for="compare" class="text-white mr-4">Compare</label>
          <select class="px-4 bg-transparent border border-green-700 rounded" aria-label="none" name="Select" id="compare" v-model="rule.compare">
            <option value="value">Value</option>
            <option v-for="option in indicators" :key="option" :value="option">{{option}}</option>
          </select>
        </div>
        <div class="my-4" v-if="rule.compare!=='value'">
          <div>
            <label for="timeframe1" class="text-white mr-4">Timeframe</label>
            <select class="px-4 bg-transparent border border-green-700 rounded" aria-label="none" name="Select" id="timeframe1" v-model="rule.value">
              <option v-for="option in timeframes" :key="option" :value="option">{{option}}</option>
            </select>
          </div>
        </div>
        <input v-else placeholder="value" aria-label="none" class="bg-transparent h-12 rounded px-4 border" type="text" v-model="rule.value">
      </div>

      <div class="flex justify-center mt-8">
        <button class="button" @click="addRule">Add</button>
      </div>
    </div>

    <div class="flex mt-4 flex-wrap">
      <div v-for="s in filter.symbols.split(' ')">
        <template v-if="s!==''">
          <div class="rounded-full text-xl text-primary bg-darker px-4 m-1">{{s}}</div>
        </template>
      </div>
    </div>

    <div class="flex justify-between mt-8">
      <router-link to="/screen" class="button">Cancel</router-link>
      <button class="button" @click="save">Save</button>
    </div>

  </div>
</template>

<script>
export default {
  name: "Filter",
  props: ['indicators', 'timeframes', 'data'],
  data(){return {
    rule: {
      compare: "value"
    },
    filter: {
      title: "Title",
      rules: [],
      symbols: "",
    },
  }},
  methods: {
    filtered(symbol){
      const compare = (a, operator, b) => {
        switch (operator){
          case '<': { return a < b; }
          case '>': { return a > b; }
          case '>=': { return a >= b; }
          case '<=': { return a <= b; }
          case '==': { return a === b; }
          case '===': { return a === b; }
          default: return false
        }
      };
      let met = true;
      this.filter.rules.forEach( (rule) => {
        met = met && (rule.compare==='value' || (rule.compare in symbol && rule.value in symbol[rule.compare]) )
        if (met)
          met = compare(symbol[rule.indicator][rule.tf], rule.condition, parseFloat(rule.compare==='value' ? rule.value : symbol[rule.compare][rule.value]))
      })
      return met;
    },
    addRule(){
      let verify = true;
      ['indicator', 'tf', 'condition', 'compare', 'value'].forEach( v => verify = verify && v in this.rule && this.rule[v]!=='')
      if (!verify) return;
      this.filter.rules.push(this.rule)
      this.filter.symbols = "";
      this.data.forEach(symbol => {
        if (this.filtered(symbol))
          this.filter.symbols += ' ' + symbol.symbol;
      })
      console.log(this.filter.symbols)
      this.rule = {};
    },
    clear(){
      this.filter = {
        title: "Title",
        rules: [],
        symbols: ""
      }
      this.rule = {}
    },
    save(){
      if ( this.filter.title!=="" && this.filter.rules.length>0 ){
        this.filter.id = this.FILTERS.doc().id;
        this.filter.created = this.FIELD_VALUE.serverTimestamp();
        this.FILTERS.doc(this.filter.id).set(this.filter).then( () => this.$router.push('/screen') )
            .catch(e => window.alert(e))
      }
    }
  }
}
</script>

<style scoped>

</style>