<template>
  <div class="card flex flex-col items-center rounded">
    <div class="text-primary text-5xl font-bold mt-12">Data Screener</div>
    <p class="text-gray text-xl m-8"> Scan the markets with unlimited indicators and timeframes </p>
    <router-link to="/screen" class="button mt-32">Get Started</router-link>
  </div>
</template>

<script>
export default {
  name: "Intro"
}
</script>

<style scoped>

</style>