<template>
  <div></div>
</template>

<script>
export default {
  name: "Feature",
  props: ['name', 'description']
}
</script>

<style scoped>

</style>