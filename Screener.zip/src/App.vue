<template>
  <div class="h-screen flex justify-center items-center overflow-auto">
    <router-view :filters="filters" :data="data" :timeframes="timeframes" :indicators="indicators"/>
  </div>
  <div class="card fixed bottom-0 right-0 left-0 text-white">created with 💗 <a href="https://lucem.dev" target="_blank">@lucem</a></div>
</template>

<script>
let listen_data; let listen_filters;
export default {
  name: "App",
  data() {return {
      filters: [],
      data: [],
      indicators: [],
      timeframes: [],
    }
  },
  created() {
    if (!listen_filters)
      listen_filters = this.FILTERS.onSnapshot( docs => {
        this.filters = []; docs.forEach( doc => {
          this.filters.push(doc.data())
        })
      })
    if (!listen_data)
      listen_data = this.DATA.onSnapshot( docs => {
        this.data = []; this.indicators = []; this.timeframes = [];
        docs.forEach( doc => {
          let data = doc.data();
          Object.keys(data).forEach( key => {
            if (key!=='symbol' && key!=='created' && typeof data[key]==='object'){
              if ( !(this.indicators.includes(key)) ) this.indicators.push(key);
              Object.keys(data[key]).forEach( tf => {
                if ( !(this.timeframes.includes(tf)) ) this.timeframes.push(tf);
              })
            }
          })
          this.data.push(data);
        })
      })
  }
}
</script>
